// export const base_url="http://primeproperty.test/api"
export const base_url = "http://localhost:4884/api/v1";
